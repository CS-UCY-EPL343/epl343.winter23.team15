from django.apps import AppConfig


class Epl343ProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'epl343Project'
