# here is the contact form and the creaseuser
from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import CustomUser



class ContactForm(forms.Form):
    name = forms.CharField(max_length=200)
    email = forms.EmailField()
    content = forms.CharField(widget=forms.Textarea)

class CreateUser(UserCreationForm):
    email = forms.EmailField()
    first_name = forms.CharField(max_length=200)
    last_name = forms.CharField(max_length=200)
    username = forms.CharField(max_length=200)
    dateofbirth = forms.DateField( )
    phone = forms.CharField(max_length=32 )
    # point = forms.IntegerField(required=False)
     

    class Meta:
        model = CustomUser
        fields = ['email' , 'password1', 'password2', 'username', 'first_name' , 'last_name', 'dateofbirth' , 'phone']
        # point=10000