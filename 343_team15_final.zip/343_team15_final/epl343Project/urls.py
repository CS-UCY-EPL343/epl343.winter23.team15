# here is the url paths, where it takes you when you press the things
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from . import views
from .views import products, add_to_cart, cart, remove_from_cart,billing_info,order_confirmed,remove_all_from_cart,my_orders

urlpatterns = [
    path('',views.home, name='home'),
    path('products/', views.products, name='products'),
    path('contactUs/', views.contactUs, name='contactUs'),
    path('deals/', views.deals, name='deals'),
    path('profile/', views.profile, name='profile'),
    path('registerLogin/', views.registerLogin, name='registerLogin'),
    path('register/', views.register, name='register'),
    path('logoutUser/', views.logoutUser , name='logoutUser'),
    path('info/', views.info , name='info'),
    path('changeEmail/', views.changeEmail , name='changeEmail'),
    path('changepass/', views.changePass , name='changePass'),
    path('ChangePhone/', views.ChangePhone , name='ChangePhone'),
    path('cart/', views.cart , name='cart'),
    path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('remove-from-cart/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
    path('cart/remove-all/', views.remove_all_from_cart, name='remove-all-from-cart'),
    path('billing-info/',billing_info,name='billing_info'),
    path('order_confirmed/',order_confirmed,name='order_confirmed'),
    path('my-orders/', my_orders, name='my_orders'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)