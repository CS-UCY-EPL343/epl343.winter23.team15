# here is set what it gonna appear to a user without account and what to a user with account
from django.core.mail import send_mail
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.template.loader import render_to_string
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login,logout,get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import CustomUser

from .decorators import unauthenticated_user

from .forms import ContactForm , CreateUser
from .models import Product, Deals, Order

from django.shortcuts import get_object_or_404, redirect, render
# Create your views here.

#@login_required(login_url='registerLogin')
def home(request):
    return render(request, 'homePage.html')

def products(request):
    features = Product.objects.all()
    return render(request, 'products.html', {'features': features})

#@login_required(login_url='registerLogin')
def contactUs(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        
        
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            content = form.cleaned_data['content']
            message_name = request.POST['name']
            html = render_to_string('emails/contactform.html', {
                'name':name,
                'email':email,
                'content':content
            })

            send_mail('The contact form subject', content, email, ['g.eleftheriou@runinfocy.com'], html_message=html) 

            return render(request, 'contactUs.html', {'form': form, 'message_name':message_name})
    else:
        form = ContactForm()
    return render(request, 'contactUs.html', {'form': form}) 

##@login_required(login_url='registerLogin')
def deals(request):
    alldeals = Deals.objects.all()
    print(alldeals)
    return render(request, 'deals.html', {'alldeals': alldeals})


@login_required(login_url='registerLogin')
def profile(request):
    return render(request, 'profile.html')

    
@login_required(login_url='registerLogin')
def info(request):
    return render(request, 'info.html')

@login_required(login_url='registerLogin')
def changeEmail(request):
    return render(request, 'changeEmail.html')

@login_required(login_url='registerLogin')
def cart(request):
    return render(request, 'cart.html')

@login_required(login_url='registerLogin')
def ChangePhone(request):
    return render(request, 'ChangePhone.html')

@login_required(login_url='registerLogin')
def changePass(request):
    return render(request, 'changePass.html')

@unauthenticated_user
def registerLogin(request):
    userData = CustomUser.objects.all()
    userData = userData.values()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if(user is not None):
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR passsword is incorrect')
            
    return render(request, 'registerLogin.html',{'userData':userData})



def logoutUser(request):
    logout(request)
    return redirect('registerLogin')


@unauthenticated_user
def register(request):
    form = CreateUser()
    
    if request.method == 'POST':
        form=CreateUser(request.POST)
        if(form.is_valid()):
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account was created for ' + user)
            return redirect('registerLogin')
        else:
            messages.success(request, 'Something went wrong. Try again..')

    return render(request, 'register.html' , context={'form':form})

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    # Check if 'cart' exists in the session
    if 'cart' not in request.session:
        request.session['cart'] = []

    # Add product id to the cart
    request.session['cart'].append(product.id)

    # Save the session
    request.session.modified = True

    return redirect('cart')

def remove_from_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    if 'cart' in request.session:
        cart_product_ids = request.session['cart']
        if product.id in cart_product_ids:
            cart_product_ids.remove(product.id)
            request.session.modified = True

    return redirect('cart')

def cart(request):
    cart_product_ids = request.session.get('cart', [])
    cart_products = Product.objects.filter(id__in=cart_product_ids)

    if request.method == 'POST':
        # Process billing information and create an order
        full_name = request.POST.get('full-name')
        address = request.POST.get('address')
        city = request.POST.get('city')
        zip_code = request.POST.get('zip-code')

        # Create an order for each product in the cart
        for product in cart_products:
            quantity = cart_product_ids.count(product.id)
            Order.objects.create(
                product=product,
                quantity=quantity,
                user=request.user,
                billing_address=f"{full_name}, {address}, {city}, {zip_code}"
            )

        # Clear the cart after creating orders
        del request.session['cart']

        messages.success(request, 'Order placed successfully!')
        return redirect('order_confirmed')

    return render(request, 'cart.html', {'cart_products': cart_products})

def remove_all_from_cart(request):
    if 'cart' in request.session:
        del request.session['cart']
    return redirect('order_confirmed')



def calculate_total_price(request):

    cart_product_ids = request.session.get('cart', [])
    cart_products = Product.objects.filter(id__in=cart_product_ids)
    total_price = sum(product.price for product in cart_products)
    
    return total_price
    

def billing_info(request):
     total_price = calculate_total_price(request)
     return render(request, 'Billing_info.html',{'total_price': total_price})

def order_confirmed(request):
    return render(request,'order-confirmed.html')



def my_orders(request):
    user_orders = Order.objects.filter(user=request.user)
    return render(request, 'myOrders.html', {'user_orders': user_orders})    

def about_us(request):
    return render(request, 'AboutUs.html')
