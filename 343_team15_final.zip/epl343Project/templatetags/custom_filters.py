# custom_filters.py
from django import template

register = template.Library()

@register.filter(name='total_price')
def total_price(cart_products):
    return sum(product.price for product in cart_products)
